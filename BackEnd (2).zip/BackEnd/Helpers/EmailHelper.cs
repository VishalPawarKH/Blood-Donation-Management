using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Configuration;

namespace BloodBankDotNetBackend.Helpers
{
    public class EmailHelper
    {
        private readonly IConfiguration _config;
        public EmailHelper(IConfiguration config)
        {
            _config = config;
        }
        public void SendEmail(string to, string subject, string body)
        {
            var smtpClient = new SmtpClient(_config["Smtp:Host"])
            {
                Port = int.Parse(_config["Smtp:Port"]),
                Credentials = new NetworkCredential(_config["Smtp:Username"], _config["Smtp:Password"]),
                EnableSsl = true,
            };
            var mailMessage = new MailMessage
            {
                From = new MailAddress(_config["Smtp:Username"]),
                Subject = subject,
                Body = body,
                IsBodyHtml = true,
            };
            mailMessage.To.Add(to);
            smtpClient.Send(mailMessage);
        }
    }
}