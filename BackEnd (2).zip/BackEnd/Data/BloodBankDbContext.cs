using Microsoft.EntityFrameworkCore;
using BloodBankDotNetBackend.Entities;

namespace BloodBankDotNetBackend.Data
{
    public class BloodBankDbContext : DbContext
    {
        public BloodBankDbContext(DbContextOptions<BloodBankDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<BloodDonation> BloodDonations { get; set; }
        public DbSet<BloodInventory> BloodInventories { get; set; }
        public DbSet<Patient> Patients { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<IdentityProof> IdentityProofs { get; set; }
    }
}