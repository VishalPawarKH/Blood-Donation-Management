using System.ComponentModel.DataAnnotations;

namespace BloodBankDotNetBackend.Entities
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
        public string Role { get; set; }
        public int? Age { get; set; }
        public string ContactNo { get; set; }
        public string Gender { get; set; }
        public string Image { get; set; }
    }
}