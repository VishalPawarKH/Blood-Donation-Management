using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BloodBankDotNetBackend.Entities
{
    public class BloodDonation
    {
        [Key]
        public int Id { get; set; }
        public DateTime DonationDate { get; set; }
        public string BloodGroup { get; set; }
        public int Quantity { get; set; }
        public int UserId { get; set; }
        [ForeignKey("UserId")]
        public User User { get; set; }
    }
}