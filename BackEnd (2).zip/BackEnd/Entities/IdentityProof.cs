using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BloodBankDotNetBackend.Entities
{
    public class IdentityProof
    {
        [Key]
        public int Id { get; set; }
        public string DocumentType { get; set; }
        public string UniqueIdNumber { get; set; }
        public int UserId { get; set; }
        [ForeignKey("UserId")]
        public User User { get; set; }
        public string Status { get; set; }
    }
}