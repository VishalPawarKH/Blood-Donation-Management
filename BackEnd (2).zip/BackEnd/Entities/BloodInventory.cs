using System.ComponentModel.DataAnnotations;

namespace BloodBankDotNetBackend.Entities
{
    public class BloodInventory
    {
        [Key]
        public int Id { get; set; }
        public string BloodGroup { get; set; }
        public int Quantity { get; set; }
        public string Center { get; set; }
    }
}