using System.Collections.Generic;
using System.Linq;
using BloodBankDotNetBackend.Data;
using BloodBankDotNetBackend.DTOs;
using BloodBankDotNetBackend.Entities;

namespace BloodBankDotNetBackend.Services
{
    public class UserService : IUserService
    {
        private readonly BloodBankDbContext _context;
        public UserService(BloodBankDbContext context)
        {
            _context = context;
        }
        public IEnumerable<UserDTO> GetAllUsers()
        {
            return _context.Users.Select(u => new UserDTO
            {
                Id = u.Id,
                FirstName = u.FirstName,
                LastName = u.LastName,
                Email = u.Email,
                Role = u.Role,
                Age = u.Age,
                ContactNo = u.ContactNo,
                Gender = u.Gender,
                Image = u.Image
            }).ToList();
        }
        public UserDTO GetUserById(int id)
        {
            var u = _context.Users.Find(id);
            if (u == null) return null;
            return new UserDTO
            {
                Id = u.Id,
                FirstName = u.FirstName,
                LastName = u.LastName,
                Email = u.Email,
                Role = u.Role,
                Age = u.Age,
                ContactNo = u.ContactNo,
                Gender = u.Gender,
                Image = u.Image
            };
        }
        public UserDTO CreateUser(UserDTO userDto)
        {
            var user = new User
            {
                FirstName = userDto.FirstName,
                LastName = userDto.LastName,
                Email = userDto.Email,
                Role = userDto.Role,
                Age = userDto.Age,
                ContactNo = userDto.ContactNo,
                Gender = userDto.Gender,
                Image = userDto.Image,
                Password = "hashedpassword" // TODO: Hash password
            };
            _context.Users.Add(user);
            _context.SaveChanges();
            userDto.Id = user.Id;
            return userDto;
        }
        public UserDTO UpdateUser(int id, UserDTO userDto)
        {
            var user = _context.Users.Find(id);
            if (user == null) return null;
            user.FirstName = userDto.FirstName;
            user.LastName = userDto.LastName;
            user.Email = userDto.Email;
            user.Role = userDto.Role;
            user.Age = userDto.Age;
            user.ContactNo = userDto.ContactNo;
            user.Gender = userDto.Gender;
            user.Image = userDto.Image;
            _context.SaveChanges();
            return userDto;
        }
        public void DeleteUser(int id)
        {
            var user = _context.Users.Find(id);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
            }
        }
    }
}