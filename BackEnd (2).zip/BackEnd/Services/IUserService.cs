using System.Collections.Generic;
using BloodBankDotNetBackend.DTOs;

namespace BloodBankDotNetBackend.Services
{
    public interface IUserService
    {
        IEnumerable<UserDTO> GetAllUsers();
        UserDTO GetUserById(int id);
        UserDTO CreateUser(UserDTO userDto);
        UserDTO UpdateUser(int id, UserDTO userDto);
        void DeleteUser(int id);
    }
}