using Microsoft.AspNetCore.Mvc;
using BloodBankDotNetBackend.DTOs;
using BloodBankDotNetBackend.Entities;
using BloodBankDotNetBackend.Data;
using BloodBankDotNetBackend.Helpers;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using System.Security.Cryptography;
using System.Text;

namespace BloodBankDotNetBackend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly BloodBankDbContext _context;
        private readonly JwtHelper _jwtHelper;
        public AuthController(BloodBankDbContext context, JwtHelper jwtHelper)
        {
            _context = context;
            _jwtHelper = jwtHelper;
        }
        [HttpPost("login")]
        public IActionResult Login([FromBody] AuthRequestDTO request)
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == request.Email);
            if (user == null || !VerifyPassword(request.Password, user.Password))
                return Unauthorized("Invalid credentials");
            var token = _jwtHelper.GenerateJwtToken(user.Email, user.Role ?? "user");
            return Ok(new AuthResponseDTO { Token = token, Email = user.Email, Role = user.Role });
        }
        [HttpPost("register")]
        public IActionResult Register([FromBody] UserDTO userDto)
        {
            if (_context.Users.Any(u => u.Email == userDto.Email))
                return BadRequest("Email already exists");
            var user = new User
            {
                FirstName = userDto.FirstName,
                LastName = userDto.LastName,
                Email = userDto.Email,
                Password = HashPassword(userDto.Password),
                Role = userDto.Role ?? "user",
                Age = userDto.Age,
                ContactNo = userDto.ContactNo,
                Gender = userDto.Gender,
                Image = userDto.Image
            };
            _context.Users.Add(user);
            _context.SaveChanges();
            return Ok();
        }
        private string HashPassword(string password)
        {
            using (var sha = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }
        private bool VerifyPassword(string password, string hashed)
        {
            return HashPassword(password) == hashed;
        }
    }
}