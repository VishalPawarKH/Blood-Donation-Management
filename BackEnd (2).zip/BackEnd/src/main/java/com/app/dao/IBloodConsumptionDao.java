package com.app.dao;

public interface IBloodConsumptionDao {

	/*
	 * 1. get blood consumption (all)
	 * 
	 * 2. get blood consumption by id
	 * 
	 * 3. save/persist/update  blood consumption 
	 * 
	 * 
	 */
}
