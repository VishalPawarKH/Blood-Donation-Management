package com.app.entities;

public enum DocumentType {
	AADHAR_CARD,PAN_CARD,VOTER_ID
}
