package com.app.entities;

public enum Center {
	SURAT,AHMEDABAD,THANE,PUNE
}
