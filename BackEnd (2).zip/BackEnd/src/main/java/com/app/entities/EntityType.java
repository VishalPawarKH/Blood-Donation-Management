package com.app.entities;

public enum EntityType {
	EVENT_ADDRESS,USER_ADDRESS
}
