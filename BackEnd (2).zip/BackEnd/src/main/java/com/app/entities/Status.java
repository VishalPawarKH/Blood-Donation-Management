package com.app.entities;

public enum Status {
	APPROVED,PENDING,REJECTED
}
