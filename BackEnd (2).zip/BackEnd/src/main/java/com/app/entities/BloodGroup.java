package com.app.entities;

public enum BloodGroup {

	O_positive,O_negative,AB_positive,AB_negative,A_positive,A_negative,B_positive,B_negative
}
