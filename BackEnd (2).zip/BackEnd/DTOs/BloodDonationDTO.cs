using System;

namespace BloodBankDotNetBackend.DTOs
{
    public class BloodDonationDTO
    {
        public int Id { get; set; }
        public DateTime DonationDate { get; set; }
        public string BloodGroup { get; set; }
        public int Quantity { get; set; }
        public int UserId { get; set; }
    }
}