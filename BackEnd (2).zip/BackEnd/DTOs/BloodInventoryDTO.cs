namespace BloodBankDotNetBackend.DTOs
{
    public class BloodInventoryDTO
    {
        public int Id { get; set; }
        public string BloodGroup { get; set; }
        public int Quantity { get; set; }
        public string Center { get; set; }
    }
}