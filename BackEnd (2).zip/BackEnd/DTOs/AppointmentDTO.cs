using System;

namespace BloodBankDotNetBackend.DTOs
{
    public class AppointmentDTO
    {
        public int Id { get; set; }
        public DateTime AppointmentCreationDate { get; set; }
        public DateTime AppointmentScheduleDate { get; set; }
        public string Status { get; set; }
        public string BloodGroup { get; set; }
        public string Center { get; set; }
        public int? BagSize { get; set; }
        public int? BagQuantity { get; set; }
        public int UserId { get; set; }
    }
}