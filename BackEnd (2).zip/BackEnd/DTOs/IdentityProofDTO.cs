namespace BloodBankDotNetBackend.DTOs
{
    public class IdentityProofDTO
    {
        public int Id { get; set; }
        public string DocumentType { get; set; }
        public string UniqueIdNumber { get; set; }
        public int UserId { get; set; }
        public string Status { get; set; }
    }
}